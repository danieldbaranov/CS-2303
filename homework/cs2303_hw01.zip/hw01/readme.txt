Daniel Baranov

These series of programs:
- repeats the number given as an argument (num program)
- calculates the average grade of the grades (the arguments given) given (grades program)
- calculates whether the year given in the arguments is a leap year (leap program)

to compile, simply type "make" in the same folder as the makefile and run the programs

MAX_GRADES in the grades program is set to 5 in the code but the actual max grades is 1 above that

I procrastinated and didn't have enough time to make calcGrades a separate source file but it still works the same
