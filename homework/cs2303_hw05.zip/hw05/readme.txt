Daniel Baranov
CS 2303 HW 05

To compile use make.

The program takes an input and puts it in the stack. The stack is dynamically allocated
and you decide how many items can be in it.

to run, use ./stacktest NUM input

I had a rough week with my other classes and I just couldn't work on this assignment.
It is half done though
