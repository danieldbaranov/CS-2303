Daniel Baranov
cs2303_hw02

at2 takes in any amount of numbers up to the maximum defined in the code.
it will then print these numbers before and after sorting them. They are doubles as well

at3 makes an array of random numbers then proceeds to sort it.
it takes in 2 parameters. One is the maximum value possible. the other is how big the array should be.

to compile, just run make in this folder. To make documentation, run make docs.

P.S.
I tried my best but for some reason at3 code looks fine to me but it just will not do anything.
